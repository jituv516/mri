<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SignauthController extends Controller
{
    //
    public function signup(){
        return view ('signup');
    }
}
