<?php

namespace App\Http\Controllers;
use App\Models\State;
use App\Models\Service;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StateController extends Controller
{
    //
    public function state_list(){
 /*   $state_list= DB::table('states')
    ->select('id','name')    
    ->get();

return view('index',compact('state_list'));*/

$users = DB::table('area_city')->select('city_id','city_name')->get();
$serviceusers = DB::table('services')->select('id','title')->Where('parent', '<=', '9')->get();

        return view('index')
        ->with('users', $users)
        ->with('serviceusers',$serviceusers);



    }

    
}
