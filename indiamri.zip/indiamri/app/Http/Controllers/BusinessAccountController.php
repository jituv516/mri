<?php

namespace App\Http\Controllers;
use App\Http\Controllers\BusinessAccountController;
use Illuminate\Http\Request;
use App\Models\business_account;
use Hash;

class BusinessAccountController extends Controller
{
    //
    public function step1(){
     return view ('Business_account.create_account1');
    }
  
    public function formSubmit(Request $request){
       // return $request->all();
      
       $request->validate([
        'password' => 'required|confirmed|min:6'
    ]);

        $formsubmit = new business_account;
        $formsubmit->user_id = $request->input('userid');
        $formsubmit->email = $request->input('email');
     
        $formsubmit->private_key= Hash::make($request->password);


        $formsubmit->country_id = $request->input('country');
        $formsubmit->state_id = $request->input('state');
        $formsubmit->city_id = $request->input('city');

        $formsubmit->name = $request->input('name');
        $formsubmit->name_father = $request->input('father_name');
        $formsubmit->dob = $request->input('dob');


          $formsubmit->mobile = $request->input('phone');
          $formsubmit->sex = $request->input('gender');
  
        $formsubmit->save();
        return redirect()->back()->with('status','Business Account Create Successfully');
   
    }
}