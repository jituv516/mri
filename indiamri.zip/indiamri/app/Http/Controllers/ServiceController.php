<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Service;
use App\Models\State;
use Illuminate\Support\Facades\DB;


class ServiceController extends Controller
{
    //
    public function services_search(){

        $service_search= DB::table('services')
        ->select('id','title')
        ->get();
        //echo $service_search;


        
    
 
       return view('index', compact('service_search'));
    }
}
