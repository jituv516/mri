<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class IndiamriController extends Controller
{
    //
    public function return_policy(){
        return view('return-policy');
    }
}
