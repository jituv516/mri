<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\CenterName;
class CenterNameController extends Controller
{
    //
    public function center_names(){
        return view ('center_details.center_name');
       }

       public function centerdetails_submit(Request $request){
       // return $request->all();

        $frmcenter = new CenterName;
        $frmcenter->user_id = $request->input('userid');
        $frmcenter->center_name = $request->input('center_name');
        $frmcenter->country_id = $request->input('country');
        $frmcenter->state_id = $request->input('state');
        $frmcenter->city_id = $request->input('city');
        $frmcenter->center_address = $request->input('center_address');
        $frmcenter->center_pin = $request->input('zip_code');
        $frmcenter->center_description = $request->input('description');

        $frmcenter->center_mobile = $request->input('mobile');
        $frmcenter->center_email = $request->input('email');
      //  $frmcenter->country = $request->input('country');
       // $frmcenter->state = $request->input('state');
       // $frmcenter->city = $request->input('city');
        $frmcenter->center_logo = $request->input('logo');

        $frmcenter->center_image1 = $request->input('certificate1');
        $frmcenter->center_image2 = $request->input('certificate2');
        $frmcenter->center_image3 = $request->input('certificate3');
        $frmcenter->center_image4 = $request->input('certificate4');

       // $frmcenter->signature = $request->input('sign');
        $frmcenter->is_trusted = $request->input('Accept');


        $frmcenter->save();
        return redirect()->back()->with('status','Center Details Create Successfully');
   
        
       }
     
       public function service_discounts()
       {
       //echo 'discounts';
        return view('center_details.service_discount');
       }
}
