<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCenterNamesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('center_names', function (Blueprint $table) {
            $table->id();
            $table->string('center_id');
            $table->string('user_id');
            $table->string('business_account_id');
            $table->string('center_name');
            $table->string('center_slug');

            $table->string('center_email');
            $table->string('center_mobile');
            $table->string('center_address');
            $table->string('center_pin');
            $table->string('center_description');

            $table->string('center_google_street');
            $table->string('center_latitude');
            $table->string('center_longitude');
            $table->string('center_contact');
            $table->string('center_logo');

            $table->string('center_image1');
            $table->string('center_image2');
            $table->string('center_image3');
            $table->string('center_image4');
            $table->string('center_status');

            $table->string('center_fee');
            $table->string('center_con_time');
            $table->string('country_id');
            $table->string('state_id');
            $table->string('city_id');

            $table->string('locality_id');
            $table->string('is_trusted');
            
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('center_names');
    }
}
