<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateBusinessAccountsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('business_accounts', function (Blueprint $table) {
            $table->id();
            $table->string('userid');
            $table->string('name');
            $table->string('name_father');
            $table->string('photo');
            $table->string('dob');
            $table->string('sex');
            $table->string('email');
            $table->string('email_code');
            $table->string('email_status');
            $table->string('mobile');
            $table->string('mobile_code');
            $table->string('mobile_status');
            $table->string('private_key');
            $table->string('country_id');
            $table->string('state_id');
            $table->string('city_id');
            $table->string('pincode');
            $table->string('hash');
            $table->datetime('date');
            $table->string('fb_token');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('business_accounts');
    }
}
