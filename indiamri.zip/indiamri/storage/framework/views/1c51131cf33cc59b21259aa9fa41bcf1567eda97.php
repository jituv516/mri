
<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta name="template" content="">
<meta name="title" content="">
<meta name="keywords" content="">
<title>Index Home 
</title>
<style>

.header-topp {
    padding: 8px 0px;
    background: #fd1731;
}
</style>
<link rel="icon" href="images/favicon.png">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/fonts/flaticon/flaticon.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/fonts/icofont/icofont.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/fonts/fontawesome/fontawesome.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/vendor/venobox/venobox.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/vendor/slickslider/slick.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/vendor/niceselect/nice-select.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/vendor/bootstrap/bootstrap.min.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/css/main.css">

<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/css/index.css">
<link rel="stylesheet" href="https://mironmahmud.com/greeny/assets/ltr/css/user-auth.css">


</head>

<body>

<div class="backdrop">
</div><a class="backtop fas fa-arrow-up" href="#"></a>

<div class="header-topp">

<div class="container">

<div class="row">

<div class="col-md-12 col-lg-5">

<div class="header-top-welcome">

<p>Welcome to 1MG!</p>
</div>
</div>

<div class="col-md-5 col-lg-3">

<div class="header-top-select">

<div class="header-select"><i class="icofont-user-plus"></i>
<select class="select">

<option value="english" selected>Login</option>

</select>
</div>

<div class="header-select"><i class="icofont-people"></i>
<select class="select">

<option value="english" selected>Signup</option>

</select>
</div>
</div>
</div>

<div class="col-md-7 col-lg-4">
<ul class="header-top-list">
<li><a href="#">offers</a></li>
<li><a href="#">need help</a></li>
<li><a href="#">contact us</a></li>
</ul>
</div>
</div>
</div>
</div>

<header cla-ss="header-part">

<div class="container">
 
<div class="header-content">

<div class="header-media-group"><button class="header-user"><img src="images/user.png" alt="user"></button><a href="index.html"><img src="https://indiamri.com/LogoFinal.jpg" alt="logo"></a><button class="header-src"><i class="fas fa-search"></i></button>
</div><a href="index.html" class="header-logo"><img src="https://indiamri.com/LogoFinal.jpg" alt="logo"></a>
<form class="header-form" style="width:50%;border: 2px solid #fd1731;"><i class="fa fa-map-marker" aria-hidden="true"></i>



<input type="text" placeholder="New Delhi" style="width:50%;">
<button><img src="location.png" style="width: 40%;"></button>
</form>
<!--
<a href="login.html" class="header-widget" title="My Account"><img src="images/user.png" alt="user">

<span>join
</-span></a>-->

<form class="header-form" style="border: 2px solid #fd1731;">



<input type="text" placeholder="Search anything...">-->

<button>

<i class="fas fa-search"></i></button>
</form>



<!--
<div class="header-widget-group"><a href="compare.html" class="header-widget" title="Compare List"><i class="fas fa-random"></i><sup>0</sup></a><a href="wishlist.html" class="header-widget" title="Wishlist"><i class="fas fa-heart"></i><sup>0</sup></a><button class="header-widget header-cart" title="Cartlist"><i class="fas fa-shopping-basket"></i><sup>9+</sup>

<span>total price<small>$345.00</small>
</span></button>
</div>-->
</div>
</div></header>

<nav class="navbar-part">

<div class="container">
<div class="row">

<div class="col-lg-12">

<div class="navbar-content">
<ul class="navbar-list">
<li class="navbar-item dropdown"><a class="navbar-link dropdown-arrow" href="#">home</a>
</li>
<li class="navbar-item dropdown-megamenu"><a class="navbar-link dropdown-arrow" href="#">shop</a>

<div class="megamenu">

<div class="container">

<div class="row">

<div class="col-lg-3">

<div class="megamenu-wrap"><h5 class="megamenu-title">shop pages</h5>

</div>
</div>

<div class="col-lg-3">

<div class="megamenu-wrap"><h5 class="megamenu-title">product pages</h5>

</div>
</div>

<div class="col-lg-3">

<div class="megamenu-wrap"><h5 class="megamenu-title">user action</h5>

</div>
</div>

<div class="col-lg-3">

<div class="megamenu-wrap"><h5 class="megamenu-title">other pages</h5>

</div>
</div>
</div>
</div>
</div></li>
<li class="navbar-item dropdown-megamenu"><a class="navbar-link dropdown-arrow" href="#">category</a>

</li>
<li class="navbar-item dropdown"><a class="navbar-link dropdown-arrow" href="#">pages</a>
</li>
<li class="navbar-item dropdown"><a class="navbar-link dropdown-arrow" href="#">authentic</a>
</li>
<li class="navbar-item dropdown"><a class="navbar-link dropdown-arrow" href="#">blogs</a>
</li>
</ul>

<div class="navbar-info-group">

<div class="navbar-info"><i class="icofont-ui-touch-phone" style="color: #fd1731;"></i>

<p><small>call us</small>

<span>(+880) 183 8288 389
</span></p>
</div>

<div class="navbar-info"><i class="icofont-ui-email" style="color: #fd1731;"></i>

<p><small>email us</small>

<span>support@example.com
</span></p>
</div>
</div>
</div>
</div>
</div>
</div></nav>


<!-----=======================================---------->
<section class="user-form-part">
<div class="container">
<div class="row justify-content-center">
<div class="col-12 col-sm-10 col-md-12 col-lg-12 col-xl-10">

<div class="user-form-logo">
  <a href="index.html">
    <!--<img src="images/logo.png" alt="logo">--></a>
</div>

<div class="user-form-card">

<div class="user-form-title"><h2>Join Now!</h2>

<p>Setup A Business Account In A Minute</p>
</div>

<div class="user-form-group">


<div class="user-form-divider">

<p>2/4</p>
</div>

<form class="user-form">



<div class="form-group">
<select class="form-select filter-select">
  <option selected="">Country</option>
  <option value="3">trending</option>
  <option value="1">featured</option>
  <option value="2">recommend</option>
</select>

</div>

<div class="form-group">
<select class="form-select filter-select">
  <option selected="">State</option>
  <option value="3">trending</option>
  <option value="1">featured</option>
  <option value="2">recommend</option>
</select>


</div>

<div class="form-group">
<select class="form-select filter-select">
  <option selected="">City</option>
  <option value="3">trending</option>
  <option value="1">featured</option>
  <option value="2">recommend</option>
</select>

</div>


<div class="form-button"><button type="submit">Next</button>
</div>
</form>
</div>
</div>

<div class="user-form-remind">

<p>Already Have An Account?<a href="login.html">login here</a></p>
</div>

<div class="user-form-footer">

<p>Greeny | © Copyright by <a href="#">Mironcoder</a></p>
</div>
</div>



</div>
</div>
</section>








<!-----========================================--------->




<footer class="footer-part">

<div class="container">

<div class="row">

<div class="col-sm-6 col-xl-3">

<div class="footer-widget"><a class="footer-logo" href="#">
<img src="https://indiamri.com/LogoFinal.jpg" alt="logo" style="width:70px;"> </a>

<p class="footer-desc">Adipisci asperiores ipsum ipsa repellat consequatur repudiandae quisquam assumenda dolor perspiciatis sit ipsum dolor amet.</p>
<!-- <ul class="footer-social">
<li><a class="icofont-facebook" href="#"></a></li>
<li><a class="icofont-twitter" href="#"></a></li>
<li><a class="icofont-linkedin" href="#"></a></li>
<li><a class="icofont-instagram" href="#"></a></li>
<li><a class="icofont-pinterest" href="#"></a></li>
</ul>-->
</div>
</div>


<div class="col-sm-6 col-xl-3">

<div class="footer-widget"><h3 class="footer-title">quick Links</h3>

<div class="footer-links">
<ul>
<li><a href="#">Know Us</a></li>
<li><a href="#">About Us</a></li>
<li><a href="#">Contact Us</a></li>
<li><a href="#">Press Coverage</a></li>
<li><a href="#">Careers</a></li>
</ul>
<ul>
<li><a href="#">Business Partnership</a></li>
<li><a href="#">Become a health Partner</a></li>
<li><a href="#">Corporate Governance</a></li>
<li><a href="#">Our Policies</a></li>
<li><a href="#">Privacy Policy</a></li>
</ul>
</div>
</div>
</div>

<div class="col-sm-6 col-xl-3">

<div class="footer-widget"><h3 class="footer-title" style="visibility:hidden;">quick Links</h3>

<div class="footer-links">
<ul>
<li><a href="#">Terms & conditions</a></li>
<li><a href="#">Editorial Policy</a></li>
<li><a href="#">Return Policy</a></li>
<li><a href="#">IP Policy</a></li>
<li><a href="#">Our Services</a></li>
</ul>
<ul>
<li><a href="#">Order Medicines</a></li>
<li><a href="#">Book Lab Tests</a></li>
<li><a href="#">Consult a Doctor</a></li>
<li><a href="#">Care Plan</a></li>
<li><a href="#">Ayurveda Articles</a></li>
</ul>
</div>
</div>
</div>

<div class="col-sm-6 col-xl-3">

<div class="footer-widget"><h3 class="footer-title">Download App</h3>

<p class="footer-desc">Lorem ipsum dolor sit amet tenetur dignissimos ipsum eligendi autem obcaecati minus ducimus totam reprehenderit exercitationem!</p>

<div class="footer-app"><a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/google-store.png" alt="google"></a><a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/app-store.png" alt="app"></a>
</div>
</div>
</div>
</div>


</div>
<div class="container-fluids">

<div class="row">

<div class="col-12">

<div class="footer-bottom" style="background-color:#fd1731">

<p class="footer-copytext">&copy; All Copyrights Reserved by <a href="#">Indiamri</a>

| <a href="">Grievance Redressal Policy </a>
| <a href="">Hindi Articles </a>
| <a href="">Connect </a>
| <a href="">Want Daily Dose Health? </a>
| <a href="">SignUp </a>

</p>

<div class="footer-card">
<a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/payment/jpg/01.jpg" alt="payment"></a>
<a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/payment/jpg/02.jpg" alt="payment"></a>
<a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/payment/jpg/03.jpg" alt="payment"></a>
<a href="#"><img src="https://mironmahmud.com/greeny/assets/ltr/images/payment/jpg/04.jpg" alt="payment"></a>
</div>
</div>
</div>
</div>
</div>

</footer>
<script>
function ipLookUp () {
  $.ajax('http://ip-api.com/json')
  .then(
      function success(response) {
          console.log('User\'s Location Data is ', response);
          console.log('User\'s Country', response.country);
          getAddress(response.lat, response.lon)
},

      function fail(data, status) {
          console.log('Request failed.  Returned status of',
                      status);
      }
  );
}

function getAddress (latitude, longitude) {
  $.ajax('https://maps.googleapis.com/maps/api/geocode/json?' +
          'latlng=' + latitude + ',' + longitude + '&key=' + 
          GOOGLE_MAP_KEY)
  .then(
    function success (response) {
      console.log('User\'s Address Data is ', response)
    },
    function fail (status) {
      console.log('Request failed.  Returned status of',
                  status)
    }
   )
}

if ("geolocation" in navigator) {
  // check if geolocation is supported/enabled on current browser
  navigator.geolocation.getCurrentPosition(
   function success(position) {
     // for when getting location is a success
     console.log('latitude', position.coords.latitude, 
                 'longitude', position.coords.longitude);
     getAddress(position.coords.latitude, 
                position.coords.longitude)
   },
  function error(error_message) {
    // for when getting location results in an error
    console.error('An error has occured while retrieving' +
                  'location', error_message)
    ipLookUp()
  });
} else {
  // geolocation is not supported
  // get your location some other way
  console.log('geolocation is not enabled on this browser')
  ipLookUp()
}

</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/bootstrap/jquery-1.12.4.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/bootstrap/popper.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/bootstrap/bootstrap.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/countdown/countdown.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/niceselect/nice-select.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/slickslider/slick.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/vendor/venobox/venobox.min.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/nice-select.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/countdown.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/accordion.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/venobox.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/slick.js">
</script>
<script src="https://mironmahmud.com/greeny/assets/ltr/js/main.js">
</script>
</body>
</html>




<?php /**PATH C:\Users\user\Desktop\mri\indiamri\resources\views/Business_account/create_account2.blade.php ENDPATH**/ ?>