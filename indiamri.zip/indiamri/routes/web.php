<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndiamriController;
use App\Http\Controllers\ServiceController;
use App\Http\Controllers\StateController;
use App\Http\Controllers\SignauthController;
use App\Http\Controllers\BusinessAccountController;
use App\Http\Controllers\CenterNameController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
/*
Route::get('/', function () {
    return view('welcome');
});*/
/*
Route::get('/', function () {
    return view('index');
});*/
//Route::get('/',[ServiceController::class,'services_search']);
 Route::get('/',[StateController::class,'state_list']);
 Route::get('return-policy',[IndiamriController::class,'return_policy']);

Route::get('sign-up',[SignauthController::class,'signup']);
Route::get('create-account-step1',[BusinessAccountController::class,'step1']);
Route::get('center-details',[CenterNameController::class,'center_names']);
Route::post('create-account-step1',[BusinessAccountController::class,'formSubmit'])->name('form.formsubmit');
Route::post('center-details',[CenterNameController::class,'centerdetails_submit'])->name('form.centerdetails');

Route::get('service_discount',[CenterNameController::class,'service_discounts']);